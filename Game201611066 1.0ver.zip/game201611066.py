
# coding: utf-8

# In[3]:

def drawAims(aims):
    for pos in aims:
        drawCircle(pos, 30)

def drawCircle(pos, radius):
    t2.penup()
    t2.goto(pos)
    t2.pendown()
    t2.circle(radius)
    
def getAims():
    global aims1
    global aims2
    aims1=list()
    aimfile=open('aims-1.txt', 'r')
    for line in aimfile:    
        line1=line.split(',')

        aims1.append((int(line1[0]),int(line1[1].strip())))

    aimfile.close()
    
    aims2=list()
    aimfile=open('aims-2.txt', 'r')
    for line in aimfile:    
        line1=line.split(',')

        aims2.append((int(line1[0]),int(line1[1].strip())))


    aimfile.close()
    
def addKeys():
    wn.onkey(keyleft, "Left")
    wn.onkey(keyright, "Right")
    wn.onkey(keyspace, " ")
    wn.onkey(keyq, "q")

def keyleft():
    global no
    if no:
        t1.left(5)

def keyright():
    global no
    if no:
        t1.right(5)
        
def keyq():
    wn.bye()
    
def keyspace():
    global k
    global j
    global y
    global score
    global no
    for i in range(0,2000):
        no=0
        t1.fd(1)
        pt=t1.pos()
        if isInAim(pt,30,aims1[0]) and k!=1:
            t1.write(score)
            t2.penup()
            t2.goto(aims1[0])
            t2.pendown()
            t2.circle(30)
            t1.clear()
            t1.penup()
            t1.goto(0,-320)
            t1.setheading(90)
            t1.pendown()
            t1.write("press <- or -> button and spacebar !")
            score=score+1
            k=1
            no=1
            if score==3:
                t1.clear()
                t1.color("black")
                t1.pencolor("black")
                t1.home()
                t1.pencolor("white")
                t1.write("Congratulations ! You WIN ! PRESS 'q' to END")
            break
        elif isInAim(pt,30,aims1[1]) and j!=1:
            t1.write(score)
            t2.penup()
            t2.goto(aims1[1])
            t2.pendown()
            t2.circle(30)
            t1.clear()
            t1.penup()
            t1.goto(0,-320)
            t1.setheading(90)
            t1.pendown()
            t1.write("press <- or -> button and spacebar !")
            score=score+1
            j=1
            no=1
            if score==3:
                t1.clear()
                t1.color("black")
                t1.pencolor("black")
                t1.home()
                t1.pencolor("white")
                t1.write("Congratulations ! You WIN ! PRESS 'q' to END")
            break
        elif isInAim(pt,30,aims1[2]) and y!=1:
            t1.write(score)
            t2.penup()
            t2.goto(aims1[2])
            t2.pendown()
            t2.circle(30)
            t1.clear()
            t1.penup()
            t1.goto(0,-320)
            t1.setheading(90)
            t1.pendown()
            t1.write("press <- or -> button and spacebar !")
            score=score+1
            y=1
            no=1
            if score==3:
                t1.clear()
                t1.color("black")
                t1.pencolor("black")
                t1.home()
                t1.pencolor("white")
                t1.write("Congratulations ! You WIN ! PRESS 'q' to END")
            break
        elif isOut(pt):
            t1.clear()
            t1.penup()
            t1.goto(0,-320)
            t1.setheading(90)
            t1.pendown()
            t1.write("press <- or -> button and spacebar !")
            no=1
            break
            
def isInAim(curpos,radius,pos):
    center=(pos[0],pos[1]+radius)
    return distance(curpos,center)<=radius

def isOut(curpos):
    return curpos[0]>480 or curpos[0]<-480 or curpos[1]>405 or curpos[1]<-405

def distance(pos1,pos2):
    import math
    return math.sqrt(math.pow(pos2[0]-pos1[0],2)+math.pow(pos2[1]-pos1[1],2))

def gamePlay():
    import turtle
    global wn
    global t1
    global t2
    global score
    global k
    global j
    global y
    global no
    score=0
    k=0
    j=0
    y=0
    no=1
    getAims()
    wn=turtle.Screen()
    wn.bgcolor("black")
    t1=turtle.Turtle()
    t1.penup()
    t1.goto(0,-320)
    t1.pendown()
    t1.left(90)
    t1.color("white")
    t1.write("press <- or -> button and spacebar !")
    t2=turtle.Turtle()
    t2.pencolor("white")
    t2.speed(15)
    drawAims(aims1)
    t2.pencolor("black")
    t2.goto(300,300)
    addKeys()
    wn.listen()
    turtle.mainloop()
    
def lab():
    gamePlay()
    
def main():
    lab()

if __name__=="__main__":
    main()

